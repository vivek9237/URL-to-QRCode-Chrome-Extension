chrome.runtime.onInstalled.addListener(function() {
alert("Thank you for Installing");
});